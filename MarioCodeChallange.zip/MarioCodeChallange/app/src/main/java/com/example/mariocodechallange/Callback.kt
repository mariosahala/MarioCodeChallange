package com.example.mariocodechallange

interface Callback {
    fun kirimStatus(status: String)
}